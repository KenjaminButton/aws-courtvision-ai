// Game types
export interface Game {
  PK: string;
  SK: string;
  gameId: string;
  date: string;
  opponent: string;
  homeAway: 'home' | 'away';
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  iowaScore: number;
  opponentScore: number;
  result: 'W' | 'L';
  period: number;
  status: string;
  venue?: string;
  attendance?: number;
}

export interface GameDetail extends Game {
  boxscore?: BoxScore;
  patterns?: Pattern[];
}

// Play types
export interface Play {
  PK: string;
  SK: string;
  playId: string;
  sequenceNumber: number;
  period: number;
  clock: string;
  description: string;
  team?: string;
  player?: string;
  playerId?: string;
  action: string;
  scoringPlay: boolean;
  pointsScored: number;
  homeScore: number;
  awayScore: number;
  shotX?: number;
  shotY?: number;
  shotMade?: boolean;
  shotType?: string;
}

// Player stats types
export interface PlayerStats {
  playerId: string;
  playerName: string;
  team: string;
  points: number;
  fieldGoalsMade: number;
  fieldGoalsAttempted: number;
  threePointersMade: number;
  threePointersAttempted: number;
  freeThrowsMade: number;
  freeThrowsAttempted: number;
  rebounds: number;
  assists: number;
  steals: number;
  blocks: number;
  turnovers: number;
  fouls: number;
  minutes?: string;
}

export interface BoxScore {
  homeTeam: {
    name: string;
    players: PlayerStats[];
    totals: PlayerStats;
  };
  awayTeam: {
    name: string;
    players: PlayerStats[];
    totals: PlayerStats;
  };
}

// Pattern types
export interface Pattern {
  PK: string;
  SK: string;
  patternType: 'scoring_run' | 'hot_streak' | 'momentum_shift';
  team: string;
  description: string;
  pointsFor?: number;
  pointsAgainst?: number;
  playerName?: string;
  playerId?: string;
  consecutiveMakes?: number;
  quarter?: number;
  detectedAt: string;
}

// Season types
export interface SeasonSummary {
  season: string;
  wins: number;
  losses: number;
  gamesPlayed: number;
  pointsPerGame: number;
  pointsAllowedPerGame: number;
}

// Player season types
export interface PlayerSeasonStats {
  playerId: string;
  playerName: string;
  team: string;
  season: string;
  gamesPlayed: number;
  totalPoints: number;
  avgPoints: number;
  totalFGMade: number;
  totalFGAttempted: number;
  fgPct: number;
  totalThreeMade: number;
  totalThreeAttempted: number;
  threePct: number;
  totalRebounds: number;
  avgRebounds: number;
  totalAssists: number;
  avgAssists: number;
}

// API Response types
export interface GamesResponse {
  games: Game[];
  season: string;
}

export interface GameDetailResponse {
  game: GameDetail;
  plays: Play[];
}

export interface PlaysResponse {
  plays: Play[];
  total: number;
}
