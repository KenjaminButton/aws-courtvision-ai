import { Link } from 'react-router-dom';
import { MapPin, Calendar, ChevronRight, Flame, TrendingUp } from 'lucide-react';
import type { Game } from '../types';

interface GameCardProps {
  game: Game;
}

export function GameCard({ game }: GameCardProps) {
  const isWin = game.result === 'W';
  const isHome = game.homeAway === 'home';
  
  // Format date nicely
  const gameDate = new Date(game.date);
  const formattedDate = gameDate.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  return (
    <Link to={`/game/${game.gameId}`} className="block">
      <div className="game-card group">
        {/* Result banner */}
        <div className={`
          h-1 w-full
          ${isWin ? 'bg-green-500' : 'bg-red-500'}
        `} />

        <div className="p-4">
          {/* Date and location */}
          <div className="flex items-center justify-between text-xs text-zinc-500 mb-3">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              {formattedDate}
            </div>
            <div className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5" />
              {isHome ? 'Home' : 'Away'}
            </div>
          </div>

          {/* Matchup */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex-1">
              <p className="text-zinc-400 text-xs uppercase tracking-wider mb-1">
                {isHome ? 'vs' : '@'}
              </p>
              <h3 className="text-lg font-semibold text-white group-hover:text-iowa-gold transition-colors">
                {game.opponent}
              </h3>
            </div>

            {/* Score */}
            <div className="text-right">
              <div className={`
                font-athletic text-3xl tracking-tight
                ${isWin ? 'text-white' : 'text-zinc-400'}
              `}>
                {game.iowaScore}
              </div>
              <div className="text-zinc-500 text-lg font-light">
                {game.opponentScore}
              </div>
            </div>
          </div>

          {/* Result badge */}
          <div className="flex items-center justify-between">
            <span className={`
              inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-bold uppercase
              ${isWin 
                ? 'bg-green-500/10 text-green-400 border border-green-500/20' 
                : 'bg-red-500/10 text-red-400 border border-red-500/20'
              }
            `}>
              {isWin ? <TrendingUp className="w-3.5 h-3.5" /> : null}
              {game.result === 'W' ? 'Win' : 'Loss'}
            </span>

            <div className="flex items-center gap-1 text-zinc-400 group-hover:text-iowa-gold transition-colors">
              <span className="text-xs">View Details</span>
              <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
}

// Compact version for lists
export function GameCardCompact({ game }: GameCardProps) {
  const isWin = game.result === 'W';
  const isHome = game.homeAway === 'home';
  
  const gameDate = new Date(game.date);
  const formattedDate = gameDate.toLocaleDateString('en-US', {
    month: 'numeric',
    day: 'numeric',
  });

  return (
    <Link to={`/game/${game.gameId}`}>
      <div className={`
        flex items-center justify-between p-3 rounded-lg
        bg-zinc-900/50 hover:bg-zinc-800 transition-colors
        border-l-2 ${isWin ? 'border-green-500' : 'border-red-500'}
      `}>
        <div className="flex items-center gap-4">
          <span className="text-zinc-500 text-sm w-12">{formattedDate}</span>
          <span className="text-zinc-400 text-xs">{isHome ? 'vs' : '@'}</span>
          <span className="text-white font-medium">{game.opponent}</span>
        </div>
        
        <div className="flex items-center gap-4">
          <span className={`font-mono ${isWin ? 'text-white' : 'text-zinc-400'}`}>
            {game.iowaScore}-{game.opponentScore}
          </span>
          <span className={`
            text-xs font-bold uppercase w-6
            ${isWin ? 'text-green-400' : 'text-red-400'}
          `}>
            {game.result}
          </span>
        </div>
      </div>
    </Link>
  );
}
