import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Play, BarChart2, Flame, Clock } from 'lucide-react';
import { useGameDetail, usePlays, useGameReplay } from '../hooks/useApi';
import { ScoreBoard, LiveScore } from '../components/ScoreBoard';
import { PlayByPlay, ReplayControls } from '../components/PlayByPlay';
import { PatternList } from '../components/PatternBadge';
import { BoxScore } from '../components/BoxScore';
import { LoadingSpinner, ErrorDisplay } from '../components/LoadingStates';

type TabType = 'overview' | 'plays' | 'replay' | 'stats';

export function GamePage() {
  const { gameId } = useParams<{ gameId: string }>();
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  
  const { data: game, loading: gameLoading, error: gameError } = useGameDetail(gameId);
  const { data: plays, loading: playsLoading } = usePlays(gameId);

  const tabs: { key: TabType; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { key: 'overview', label: 'Overview', icon: BarChart2 },
    { key: 'plays', label: 'Play-by-Play', icon: Clock },
    { key: 'replay', label: 'Replay', icon: Play },
    { key: 'stats', label: 'Box Score', icon: Flame },
  ];

  if (gameLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <LoadingSpinner message="Loading game data..." />
      </div>
    );
  }

  if (gameError || !game) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <ErrorDisplay
          title="Game not found"
          message="We couldn't find this game. It may have been moved or deleted."
        />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Back navigation */}
      <Link 
        to="/"
        className="inline-flex items-center gap-2 text-zinc-400 hover:text-white mb-6 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Games
      </Link>

      {/* Score header */}
      <div className="mb-8">
        <ScoreBoard game={game} />
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-zinc-800 mb-6 overflow-x-auto">
        {tabs.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setActiveTab(key)}
            className={`
              flex items-center gap-2 px-4 py-3 text-sm font-medium
              transition-colors relative whitespace-nowrap
              ${activeTab === key 
                ? 'text-iowa-gold' 
                : 'text-zinc-500 hover:text-white'
              }
            `}
          >
            <Icon className="w-4 h-4" />
            {label}
            {activeTab === key && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-iowa-gold" />
            )}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div className="min-h-[400px]">
        {activeTab === 'overview' && (
          <OverviewTab game={game} plays={plays || []} />
        )}
        {activeTab === 'plays' && (
          <PlaysTab plays={plays || []} loading={playsLoading} />
        )}
        {activeTab === 'replay' && (
          <ReplayTab gameId={gameId!} game={game} />
        )}
        {activeTab === 'stats' && (
          <StatsTab game={game} />
        )}
      </div>
    </div>
  );
}

// Overview tab showing patterns and key stats
function OverviewTab({ game, plays }: { game: any; plays: any[] }) {
  // Mock patterns - in real app, fetch from API
  const mockPatterns = [
    {
      PK: game.PK,
      SK: 'PATTERN#1',
      patternType: 'scoring_run' as const,
      team: 'Iowa Hawkeyes',
      description: 'Iowa 12-2 run in Q3',
      pointsFor: 12,
      pointsAgainst: 2,
      quarter: 3,
      detectedAt: new Date().toISOString(),
    },
    {
      PK: game.PK,
      SK: 'PATTERN#2',
      patternType: 'hot_streak' as const,
      team: 'Iowa Hawkeyes',
      playerName: 'Hannah Stuelke',
      description: 'Hannah Stuelke - 4 consecutive makes',
      consecutiveMakes: 4,
      quarter: 2,
      detectedAt: new Date().toISOString(),
    },
  ];

  // Calculate quick stats from plays
  const scoringPlays = plays.filter(p => p.scoringPlay);
  const iowaScoring = scoringPlays.filter(p => p.team?.toLowerCase().includes('iowa'));
  
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Patterns */}
      <div className="lg:col-span-2">
        <PatternList patterns={mockPatterns} />
      </div>

      {/* Quick stats sidebar */}
      <div className="space-y-4">
        <div className="bg-zinc-900 rounded-xl border border-zinc-800 p-4">
          <h3 className="font-semibold text-white mb-4">Quick Stats</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-zinc-400">Total Plays</span>
              <span className="text-white font-mono">{plays.length}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-zinc-400">Scoring Plays</span>
              <span className="text-white font-mono">{scoringPlays.length}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-zinc-400">Iowa Scoring</span>
              <span className="text-iowa-gold font-mono">{iowaScoring.length}</span>
            </div>
          </div>
        </div>

        {/* Game info */}
        <div className="bg-zinc-900 rounded-xl border border-zinc-800 p-4">
          <h3 className="font-semibold text-white mb-4">Game Info</h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between items-center">
              <span className="text-zinc-400">Date</span>
              <span className="text-white">
                {new Date(game.date).toLocaleDateString()}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-zinc-400">Location</span>
              <span className="text-white">
                {game.homeAway === 'home' ? 'Home' : 'Away'}
              </span>
            </div>
            {game.venue && (
              <div className="flex justify-between items-center">
                <span className="text-zinc-400">Venue</span>
                <span className="text-white">{game.venue}</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Plays tab with full play-by-play
function PlaysTab({ plays, loading }: { plays: any[]; loading: boolean }) {
  if (loading) {
    return <LoadingSpinner message="Loading plays..." />;
  }

  return <PlayByPlay plays={plays} />;
}

// Replay tab with interactive replay
function ReplayTab({ gameId, game }: { gameId: string; game: any }) {
  const {
    plays,
    currentPlay,
    currentPlayIndex,
    isPlaying,
    speed,
    progress,
    loading,
    play,
    pause,
    reset,
    setSpeed,
  } = useGameReplay(gameId);

  if (loading) {
    return <LoadingSpinner message="Loading replay data..." />;
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Live score and controls */}
      <div className="lg:col-span-1 space-y-4">
        {currentPlay && (
          <LiveScore
            homeScore={currentPlay.homeScore}
            awayScore={currentPlay.awayScore}
            homeTeam={game.homeTeam || 'Home'}
            awayTeam={game.awayTeam || 'Away'}
            period={currentPlay.period}
            clock={currentPlay.clock}
          />
        )}

        <ReplayControls
          isPlaying={isPlaying}
          speed={speed}
          progress={progress}
          onPlay={play}
          onPause={pause}
          onReset={reset}
          onSpeedChange={setSpeed}
        />

        {/* Current play info */}
        {currentPlay && (
          <div className="bg-zinc-900 rounded-xl border border-zinc-800 p-4">
            <h4 className="text-sm text-zinc-500 uppercase tracking-wider mb-2">
              Current Play
            </h4>
            <p className="text-white">
              {currentPlay.description}
            </p>
            {currentPlay.scoringPlay && (
              <span className="inline-flex items-center gap-1 mt-2 text-iowa-gold text-sm font-bold">
                <Flame className="w-4 h-4" />
                +{currentPlay.pointsScored} PTS
              </span>
            )}
          </div>
        )}
      </div>

      {/* Play-by-play list */}
      <div className="lg:col-span-2">
        <PlayByPlay
          plays={plays || []}
          currentPlayIndex={currentPlayIndex}
          isReplayMode={true}
        />
      </div>
    </div>
  );
}

// Stats tab with box score
function StatsTab({ game }: { game: any }) {
  // Mock boxscore - in real app, get from game.boxscore
  const mockBoxscore = {
    homeTeam: {
      name: game.homeAway === 'home' ? 'Iowa Hawkeyes' : game.opponent || 'Opponent',
      players: [
        {
          playerId: '1',
          playerName: 'Hannah Stuelke',
          team: 'Iowa',
          points: 24,
          fieldGoalsMade: 10,
          fieldGoalsAttempted: 18,
          threePointersMade: 0,
          threePointersAttempted: 0,
          freeThrowsMade: 4,
          freeThrowsAttempted: 5,
          rebounds: 8,
          assists: 2,
          steals: 1,
          blocks: 2,
          turnovers: 2,
          fouls: 2,
          minutes: '32:00',
        },
        {
          playerId: '2',
          playerName: 'Lucy Olsen',
          team: 'Iowa',
          points: 18,
          fieldGoalsMade: 6,
          fieldGoalsAttempted: 14,
          threePointersMade: 2,
          threePointersAttempted: 5,
          freeThrowsMade: 4,
          freeThrowsAttempted: 4,
          rebounds: 4,
          assists: 6,
          steals: 2,
          blocks: 0,
          turnovers: 3,
          fouls: 1,
          minutes: '35:00',
        },
      ],
      totals: {
        playerId: 'totals',
        playerName: 'TOTALS',
        team: 'Iowa',
        points: 85,
        fieldGoalsMade: 30,
        fieldGoalsAttempted: 65,
        threePointersMade: 8,
        threePointersAttempted: 22,
        freeThrowsMade: 17,
        freeThrowsAttempted: 20,
        rebounds: 38,
        assists: 18,
        steals: 8,
        blocks: 4,
        turnovers: 12,
        fouls: 15,
      },
    },
    awayTeam: {
      name: game.homeAway === 'away' ? 'Iowa Hawkeyes' : game.opponent || 'Opponent',
      players: [],
      totals: {
        playerId: 'totals',
        playerName: 'TOTALS',
        team: game.opponent || 'Opponent',
        points: 72,
        fieldGoalsMade: 25,
        fieldGoalsAttempted: 60,
        threePointersMade: 6,
        threePointersAttempted: 18,
        freeThrowsMade: 16,
        freeThrowsAttempted: 22,
        rebounds: 32,
        assists: 14,
        steals: 5,
        blocks: 2,
        turnovers: 15,
        fouls: 18,
      },
    },
  };

  return (
    <BoxScore 
      boxscore={game.boxscore || mockBoxscore} 
      highlightIowa={true} 
    />
  );
}
